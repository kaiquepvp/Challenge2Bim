/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projeto_final_2bi;

/**
 *
 * @author erick.pmoreira
 */
public class VariaveisGlobais {
      
    static String vlogin = "";
    static String vsenha = "";
    
    static String login = "normal";
    static String senha = "1234";
    
    static String admlogin = "adm";
    static String admsenha = "adm";
    
    
    static int cont_vis = 0;
    static int cont_pal = 0;
    static int cont_fun = 0;
}

